/*
Navicat MySQL Data Transfer

Source Server         : byl
Source Server Version : 50538
Source Host           : localhost:3306
Source Database       : neusoft_system

Target Server Type    : MYSQL
Target Server Version : 50538
File Encoding         : 65001

Date: 2017-04-09 21:07:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for article_info
-- ----------------------------
DROP TABLE IF EXISTS `article_info`;
CREATE TABLE `article_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(30) NOT NULL DEFAULT '',
  `article_content` text,
  `parent` varchar(30) NOT NULL DEFAULT '0',
  `tagid` int(11) unsigned zerofill NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=292 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of article_info
-- ----------------------------
INSERT INTO `article_info` VALUES ('10', 'python', '1', '#', '00000000004');
INSERT INTO `article_info` VALUES ('12', 'python简介', '2', '10', '00000000004');
INSERT INTO `article_info` VALUES ('13', 'python解释器', '3', '12', '00000000004');
INSERT INTO `article_info` VALUES ('14', 'Python框架', '3', '12', '00000000004');
INSERT INTO `article_info` VALUES ('15', '安装python', '2', '10', '00000000004');
INSERT INTO `article_info` VALUES ('16', 'linux安装', '3', '15', '00000000004');
INSERT INTO `article_info` VALUES ('17', 'python基础', '2', '10', '00000000004');
INSERT INTO `article_info` VALUES ('18', 'python_markdown', '2', '10', '00000000004');
INSERT INTO `article_info` VALUES ('19', 'php', '0', '#', '00000000007');
INSERT INTO `article_info` VALUES ('21', 'php简介', '2', '19', '00000000007');
INSERT INTO `article_info` VALUES ('22', 'php安装', '2', '19', '00000000007');
INSERT INTO `article_info` VALUES ('23', 'c', '0', '#', '00000000008');
INSERT INTO `article_info` VALUES ('24', 'c语言简介', '2', '23', '00000000008');
INSERT INTO `article_info` VALUES ('25', 'oracle', '0', '#', '00000000009');
INSERT INTO `article_info` VALUES ('26', 'oracle hello', '2', '25', '00000000009');
INSERT INTO `article_info` VALUES ('27', 'oracle anzhuang', '3', '26', '00000000009');
INSERT INTO `article_info` VALUES ('28', 'java基础', '0', '#', '00000000010');
INSERT INTO `article_info` VALUES ('29', 'java基础语法', '3', '60', '00000000010');
INSERT INTO `article_info` VALUES ('30', 'java高级', '0', '#', '00000000011');
INSERT INTO `article_info` VALUES ('32', '文件，目录操作', '3', '46', '00000000011');
INSERT INTO `article_info` VALUES ('33', '字节流', '3', '46', '00000000011');
INSERT INTO `article_info` VALUES ('34', '字符流', '3', '46', '00000000011');
INSERT INTO `article_info` VALUES ('35', '序列流', '3', '46', '00000000011');
INSERT INTO `article_info` VALUES ('36', '对象的序列化', '3', '46', '00000000011');
INSERT INTO `article_info` VALUES ('37', '打印流', '3', '46', '00000000011');
INSERT INTO `article_info` VALUES ('38', '编码和解码', '3', '46', '00000000011');
INSERT INTO `article_info` VALUES ('39', '转换流', '3', '46', '00000000011');
INSERT INTO `article_info` VALUES ('40', '集合类', '2', '30', '00000000011');
INSERT INTO `article_info` VALUES ('41', '概述', '3', '40', '00000000011');
INSERT INTO `article_info` VALUES ('42', '单列集合', '3', '40', '00000000011');
INSERT INTO `article_info` VALUES ('43', '双列集合', '3', '40', '00000000011');
INSERT INTO `article_info` VALUES ('44', 'COLLECTIONS和ARRAYS常用方法', '3', '40', '00000000011');
INSERT INTO `article_info` VALUES ('46', '文件操作', '2', '30', '00000000011');
INSERT INTO `article_info` VALUES ('47', '变量和数据类型', '3', '60', '00000000010');
INSERT INTO `article_info` VALUES ('48', '运算操作符', '3', '60', '00000000010');
INSERT INTO `article_info` VALUES ('49', '字符串', '3', '60', '00000000010');
INSERT INTO `article_info` VALUES ('50', '流程控制', '3', '60', '00000000010');
INSERT INTO `article_info` VALUES ('51', '输入输出', '3', '60', '00000000010');
INSERT INTO `article_info` VALUES ('52', '类和对象', '3', '61', '00000000010');
INSERT INTO `article_info` VALUES ('53', '组合，继承和多态', '3', '61', '00000000010');
INSERT INTO `article_info` VALUES ('59', 'Java开发环境搭建', '2', '28', '00000000010');
INSERT INTO `article_info` VALUES ('60', '初识java编程', '2', '28', '00000000010');
INSERT INTO `article_info` VALUES ('61', '面向对象', '2', '28', '00000000010');
INSERT INTO `article_info` VALUES ('62', 'javascript', '0', '#', '00000000012');
INSERT INTO `article_info` VALUES ('63', '初识javascript', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('66', 'js数据类型和运算符', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('67', 'js分支选择结构', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('68', 'js循环结构', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('69', 'js函数', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('70', 'js数组', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('71', '数组', '3', '60', '00000000010');
INSERT INTO `article_info` VALUES ('72', 'eclipse工具使用', '0', '#', '00000000013');
INSERT INTO `article_info` VALUES ('73', '基本设置', '2', '72', '00000000013');
INSERT INTO `article_info` VALUES ('74', 'html/css', '0', '#', '00000000014');
INSERT INTO `article_info` VALUES ('75', '数据库', '0', '#', '00000000015');
INSERT INTO `article_info` VALUES ('76', 'jquery', '0', '#', '00000000016');
INSERT INTO `article_info` VALUES ('77', 'servlet/jsp', '0', '#', '00000000017');
INSERT INTO `article_info` VALUES ('78', 'spring', '0', '#', '00000000018');
INSERT INTO `article_info` VALUES ('79', 'springmvc', '0', '#', '00000000019');
INSERT INTO `article_info` VALUES ('80', 'mybatis简介', '0', '#', '00000000020');
INSERT INTO `article_info` VALUES ('81', 'js字符串操作和数学函数', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('82', 'js BOM操作', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('83', 'js DOM操作', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('84', 'js事件', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('85', 'js事件对象', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('86', 'js日期和时间', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('87', 'js正则表达式', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('88', 'js面向对象', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('89', 'js原型', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('90', 'ES2015新特性', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('91', 'ES2015新特性2', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('92', '初识JQuery', '2', '76', '00000000016');
INSERT INTO `article_info` VALUES ('93', 'JQuery选择器', '2', '76', '00000000016');
INSERT INTO `article_info` VALUES ('94', 'JQuery dom操作', '2', '76', '00000000016');
INSERT INTO `article_info` VALUES ('95', 'JQuery事件', '2', '76', '00000000016');
INSERT INTO `article_info` VALUES ('96', 'JQuery动画', '2', '76', '00000000016');
INSERT INTO `article_info` VALUES ('97', 'JQuery表单操作', '2', '76', '00000000016');
INSERT INTO `article_info` VALUES ('99', 'JQuery表格操作', '2', '76', '00000000016');
INSERT INTO `article_info` VALUES ('100', '综合案列', '2', '76', '00000000016');
INSERT INTO `article_info` VALUES ('101', 'mybatis基本增删改查', '2', '80', '00000000020');
INSERT INTO `article_info` VALUES ('102', 'mybatis开发dao层', '2', '80', '00000000020');
INSERT INTO `article_info` VALUES ('103', 'mybatis查询结果映射', '2', '80', '00000000020');
INSERT INTO `article_info` VALUES ('104', 'mybatis高级主题', '2', '80', '00000000020');
INSERT INTO `article_info` VALUES ('105', 'springmvc框架原理', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('106', '非注解的处理器映射器和适配器', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('107', '注解的处理器映射器和适配器', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('108', 'springmvc前端控制器', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('109', 'springmvc小结', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('110', 'springmvc整合mybatis', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('111', 'springmvc整合mybatis之mapper', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('112', 'springmvc整合mybatis之service', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('113', 'springmvc整合mybatis之controller', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('114', 'springmvc注解开发之商品修改功能', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('115', 'springmvc注解开发之简单参数绑定', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('116', 'springmvc注解开发之包装类型参数绑定', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('117', 'springmvc注解开发之集合类型参数绑定', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('118', '搭建Java开发环境(一)', '3', '59', '00000000010');
INSERT INTO `article_info` VALUES ('119', '搭建Java开发环境(二)', '3', '59', '00000000010');
INSERT INTO `article_info` VALUES ('121', '方法', '3', '60', '00000000010');
INSERT INTO `article_info` VALUES ('122', 'springmvc数据回显', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('123', 'springmvc图片上传', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('124', 'springmvc json数据交互', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('125', 'springmvc restful支持', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('126', 'springmvc拦截器', '2', '79', '00000000019');
INSERT INTO `article_info` VALUES ('127', '框架基础', '2', '78', '00000000018');
INSERT INTO `article_info` VALUES ('128', 'java反射机制一', '3', '127', '00000000018');
INSERT INTO `article_info` VALUES ('129', 'java反射机制二', '3', '127', '00000000018');
INSERT INTO `article_info` VALUES ('130', 'java反射机制三', '3', '127', '00000000018');
INSERT INTO `article_info` VALUES ('131', 'java注解解析一', '3', '127', '00000000018');
INSERT INTO `article_info` VALUES ('132', 'java注解解析二', '3', '127', '00000000018');
INSERT INTO `article_info` VALUES ('133', 'JavaWeb开发入门（一）', '3', '135', '00000000017');
INSERT INTO `article_info` VALUES ('134', 'JavaWeb开发入门（二）', '3', '135', '00000000017');
INSERT INTO `article_info` VALUES ('135', 'javaweb基础知识', '2', '77', '00000000017');
INSERT INTO `article_info` VALUES ('136', 'servlet', '2', '77', '00000000017');
INSERT INTO `article_info` VALUES ('137', 'jsp', '2', '77', '00000000017');
INSERT INTO `article_info` VALUES ('138', 'javaweb开发环境搭建', '3', '135', '00000000017');
INSERT INTO `article_info` VALUES ('139', 'HTTP协议详解', '3', '135', '00000000017');
INSERT INTO `article_info` VALUES ('141', '初识JSP', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('142', 'JSP指令介绍', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('143', 'JSP运行原理及九大隐式对象 ', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('144', 'JSP属性范围', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('145', 'JSP标签介绍', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('146', 'JavaBean介绍', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('147', 'JavaWeb的两种开发模式 ', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('148', '开发实战之用户登录注册', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('149', '开发实战之购物车', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('150', 'EL表达式', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('151', 'JSTL标签库', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('152', 'JDBC用户登录注册', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('153', 'JDBC客户关系管理', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('154', '客户管理管理分页', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('155', '学生信息管理分页', '3', '137', '00000000017');
INSERT INTO `article_info` VALUES ('156', 'JavaWeb状态保持技术', '2', '77', '00000000017');
INSERT INTO `article_info` VALUES ('157', 'Cookie', '3', '156', '00000000017');
INSERT INTO `article_info` VALUES ('158', '过滤器', '2', '77', '00000000017');
INSERT INTO `article_info` VALUES ('159', '过滤器一', '3', '158', '00000000017');
INSERT INTO `article_info` VALUES ('160', '过滤器应用之统一编码', '3', '158', '00000000017');
INSERT INTO `article_info` VALUES ('161', '过滤器应用之自动登录', '3', '158', '00000000017');
INSERT INTO `article_info` VALUES ('162', '过滤器应用之Decorator', '3', '158', '00000000017');
INSERT INTO `article_info` VALUES ('163', '过滤器应用之敏感词过滤', '3', '158', '00000000017');
INSERT INTO `article_info` VALUES ('164', 'Servlet开发（1）', '3', '136', '00000000017');
INSERT INTO `article_info` VALUES ('165', 'Servlet开发（2）', '3', '136', '00000000017');
INSERT INTO `article_info` VALUES ('166', 'HttpServletRequest', '3', '136', '00000000017');
INSERT INTO `article_info` VALUES ('167', 'HttpServletResponse', '3', '136', '00000000017');
INSERT INTO `article_info` VALUES ('168', 'servlet和session实现验证码', '3', '136', '00000000017');
INSERT INTO `article_info` VALUES ('170', 'html', '2', '74', '00000000014');
INSERT INTO `article_info` VALUES ('171', 'css', '2', '74', '00000000014');
INSERT INTO `article_info` VALUES ('172', '第一个例子p，img，hn', '3', '170', '00000000014');
INSERT INTO `article_info` VALUES ('173', 'html文本标签', '4', '172', '00000000014');
INSERT INTO `article_info` VALUES ('174', '第二个例子a,ul,li', '3', '170', '00000000014');
INSERT INTO `article_info` VALUES ('175', 'html图像标签', '4', '172', '00000000014');
INSERT INTO `article_info` VALUES ('176', 'html超级链接标签', '4', '174', '00000000014');
INSERT INTO `article_info` VALUES ('177', 'html表格', '3', '170', '00000000014');
INSERT INTO `article_info` VALUES ('178', 'html列表标签', '4', '174', '00000000014');
INSERT INTO `article_info` VALUES ('179', 'html表单', '3', '170', '00000000014');
INSERT INTO `article_info` VALUES ('180', '接口和抽象类对比', '3', '61', '00000000010');
INSERT INTO `article_info` VALUES ('181', '访问数据库', '2', '30', '00000000011');
INSERT INTO `article_info` VALUES ('182', 'jdbc', '3', '181', '00000000011');
INSERT INTO `article_info` VALUES ('183', 'dbutils', '3', '181', '00000000011');
INSERT INTO `article_info` VALUES ('185', 'css选择器', '3', '171', '00000000014');
INSERT INTO `article_info` VALUES ('186', 'css文本样式一', '3', '171', '00000000014');
INSERT INTO `article_info` VALUES ('187', 'css文本样式二', '3', '171', '00000000014');
INSERT INTO `article_info` VALUES ('188', 'css盒子模型', '3', '171', '00000000014');
INSERT INTO `article_info` VALUES ('189', 'css浮动定位', '3', '171', '00000000014');
INSERT INTO `article_info` VALUES ('190', 'css绝对定位和相对定位', '3', '171', '00000000014');
INSERT INTO `article_info` VALUES ('191', '变量和数据类型练习题', '4', '47', '00000000010');
INSERT INTO `article_info` VALUES ('192', 'IOC', '2', '78', '00000000018');
INSERT INTO `article_info` VALUES ('193', '声明一个简单的bean', '3', '192', '00000000018');
INSERT INTO `article_info` VALUES ('194', '构造器注入', '3', '192', '00000000018');
INSERT INTO `article_info` VALUES ('195', '注入bean属性', '3', '192', '00000000018');
INSERT INTO `article_info` VALUES ('196', 'js实战', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('197', 'js打字游戏', '3', '196', '00000000012');
INSERT INTO `article_info` VALUES ('198', 'linux', '0', '#', '00000000021');
INSERT INTO `article_info` VALUES ('199', '新技术', '0', '#', '00000000022');
INSERT INTO `article_info` VALUES ('200', '其他', '0', '#', '00000000023');
INSERT INTO `article_info` VALUES ('201', 'react.js入门', '2', '199', '00000000022');
INSERT INTO `article_info` VALUES ('202', 'vue.js入门', '2', '199', '00000000022');
INSERT INTO `article_info` VALUES ('203', 'svn使用教程', '2', '200', '00000000023');
INSERT INTO `article_info` VALUES ('204', 'git使用教程', '2', '200', '00000000023');
INSERT INTO `article_info` VALUES ('206', 'html_css_实例', '2', '74', '00000000014');
INSERT INTO `article_info` VALUES ('207', 'dl，dt，dd常见用法', '3', '206', '00000000014');
INSERT INTO `article_info` VALUES ('208', '商品列表', '4', '207', '00000000014');
INSERT INTO `article_info` VALUES ('209', 'ul，li常见用法', '3', '206', '00000000014');
INSERT INTO `article_info` VALUES ('210', '新闻标题分栏显示 ', '4', '209', '00000000014');
INSERT INTO `article_info` VALUES ('211', 'dl dt dd常用的用法 ', '4', '207', '00000000014');
INSERT INTO `article_info` VALUES ('212', 'dl dt dd实战', '4', '207', '00000000014');
INSERT INTO `article_info` VALUES ('213', '商品明细', '3', '196', '00000000012');
INSERT INTO `article_info` VALUES ('214', '瑜伽网站实战', '3', '206', '00000000014');
INSERT INTO `article_info` VALUES ('215', '包', '3', '61', '00000000010');
INSERT INTO `article_info` VALUES ('216', 'java object基类', '3', '61', '00000000010');
INSERT INTO `article_info` VALUES ('217', 'java字符串常用操作总结', '3', '60', '00000000010');
INSERT INTO `article_info` VALUES ('218', 'java静态变量', '3', '61', '00000000010');
INSERT INTO `article_info` VALUES ('220', 'java date calendar', '3', '61', '00000000010');
INSERT INTO `article_info` VALUES ('221', '绝对定位应用', '4', '190', '00000000014');
INSERT INTO `article_info` VALUES ('222', '数组常用操作', '3', '70', '00000000012');
INSERT INTO `article_info` VALUES ('223', '数组常用操作二', '3', '70', '00000000012');
INSERT INTO `article_info` VALUES ('224', '字符串常用操作', '3', '81', '00000000012');
INSERT INTO `article_info` VALUES ('225', '字符串常用操作二', '3', '81', '00000000012');
INSERT INTO `article_info` VALUES ('226', '深入理解JSON', '2', '62', '00000000012');
INSERT INTO `article_info` VALUES ('227', '鼠标事件', '3', '84', '00000000012');
INSERT INTO `article_info` VALUES ('228', '鼠标事件二', '3', '84', '00000000012');
INSERT INTO `article_info` VALUES ('231', 'bootstrap实战教程', '2', '200', '00000000023');
INSERT INTO `article_info` VALUES ('233', 'Session', '3', '156', '00000000017');
INSERT INTO `article_info` VALUES ('234', 'Session应用之防止表单重复提交', '3', '156', '00000000017');
INSERT INTO `article_info` VALUES ('236', '监听器', '2', '77', '00000000017');
INSERT INTO `article_info` VALUES ('237', '文件上传与下载', '2', '77', '00000000017');
INSERT INTO `article_info` VALUES ('240', 'Servlet事件监听器(一) ', '3', '236', '00000000017');
INSERT INTO `article_info` VALUES ('241', '监听器应用一', '3', '236', '00000000017');
INSERT INTO `article_info` VALUES ('242', 'Servlet事件监听器（二）', '3', '236', '00000000017');
INSERT INTO `article_info` VALUES ('243', '监听器应用二', '3', '236', '00000000017');
INSERT INTO `article_info` VALUES ('244', '文件上传一', '3', '237', '00000000017');
INSERT INTO `article_info` VALUES ('245', '文件上传二', '3', '237', '00000000017');
INSERT INTO `article_info` VALUES ('246', '文件上传三', '3', '237', '00000000017');
INSERT INTO `article_info` VALUES ('247', '文件下载', '3', '237', '00000000017');
INSERT INTO `article_info` VALUES ('248', '文件上传下载系统', '3', '237', '00000000017');
INSERT INTO `article_info` VALUES ('252', 'intelij搭建web项目', '2', '200', '00000000023');
INSERT INTO `article_info` VALUES ('253', 'hhtml', '3', '206', '00000000014');
INSERT INTO `article_info` VALUES ('255', 'struts', '0', '#', '00000000025');
INSERT INTO `article_info` VALUES ('256', 'Struts2框架入门', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('257', 'Struts2的Action详解', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('258', 'Struts2动态方法调用', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('259', 'Struts2拦截器', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('260', 'Struts2文件上传', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('261', 'Struts2常用servlet对象获取', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('262', 'Struts2自定义类型转换器', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('263', 'Struts2接收请求参数', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('264', 'Struts2输入校验', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('265', 'Struts2国际化', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('266', 'Struts2之OGNL表达式', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('267', 'Struts2标签', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('268', '自动装配Bean属性', '3', '192', '00000000018');
INSERT INTO `article_info` VALUES ('269', '使用注解装配bean', '3', '192', '00000000018');
INSERT INTO `article_info` VALUES ('270', '自动检测', '3', '192', '00000000018');
INSERT INTO `article_info` VALUES ('271', 'Hibernate', '0', '#', '00000000026');
INSERT INTO `article_info` VALUES ('272', 'Java对象持久化概述', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('273', 'Hibernate入门', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('274', 'Eclipse在线配置Hibernate Tools', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('275', 'Hibernate API及Hibernate主配置文件', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('276', '映射普通属性', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('278', '映射主键属性', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('279', '映射集合属性', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('280', '一对多关联关系映射', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('281', '多对多关联关系映射', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('282', 'cascade属性', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('283', '在Hibernate中java对象的状态', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('284', '操纵持久化对象的方法（Session中）', '2', '271', '00000000026');
INSERT INTO `article_info` VALUES ('285', '深入理解Struts2值栈', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('286', '数据传输的背后机制值栈', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('287', 'Struts2中的数据传输总结', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('288', 'Struts2文件下载', '2', '255', '00000000025');
INSERT INTO `article_info` VALUES ('289', 'AOP', '2', '78', '00000000018');
INSERT INTO `article_info` VALUES ('290', 'SSH整合', '2', '78', '00000000018');
INSERT INTO `article_info` VALUES ('291', 'artTemplate入门', '2', '199', '00000000022');

-- ----------------------------
-- Table structure for article_info_true
-- ----------------------------
DROP TABLE IF EXISTS `article_info_true`;
CREATE TABLE `article_info_true` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_title` varchar(30) NOT NULL DEFAULT '',
  `article_content` longtext,
  `nodeid` int(11) NOT NULL DEFAULT '0',
  `mark_content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for class_info
-- ----------------------------
DROP TABLE IF EXISTS `class_info`;
CREATE TABLE `class_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of class_info
-- ----------------------------
INSERT INTO `class_info` VALUES ('1', 'java19班');
INSERT INTO `class_info` VALUES ('2', 'java20班');

-- ----------------------------
-- Table structure for student_info
-- ----------------------------
DROP TABLE IF EXISTS `student_info`;
CREATE TABLE `student_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_name` varchar(64) NOT NULL DEFAULT '',
  `student_pass` varchar(64) NOT NULL DEFAULT '',
  `class_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `student_info_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student_info
-- ----------------------------
INSERT INTO `student_info` VALUES ('1', 'admin', 'songbo982514', '1');

-- ----------------------------
-- Table structure for tag_info
-- ----------------------------
DROP TABLE IF EXISTS `tag_info`;
CREATE TABLE `tag_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tag_info
-- ----------------------------
INSERT INTO `tag_info` VALUES ('10', 'java基础');
INSERT INTO `tag_info` VALUES ('11', 'java高级');
INSERT INTO `tag_info` VALUES ('12', 'javascript');
INSERT INTO `tag_info` VALUES ('14', 'html/css');
INSERT INTO `tag_info` VALUES ('16', 'jquery');
INSERT INTO `tag_info` VALUES ('17', 'servlet/jsp');
INSERT INTO `tag_info` VALUES ('18', 'spring');
INSERT INTO `tag_info` VALUES ('19', 'springmvc');
INSERT INTO `tag_info` VALUES ('20', 'mybatis');
INSERT INTO `tag_info` VALUES ('22', '新技术');
INSERT INTO `tag_info` VALUES ('23', '工具');
INSERT INTO `tag_info` VALUES ('25', 'struts');
INSERT INTO `tag_info` VALUES ('26', 'Hibernate');
